/*
 * CS1050 - Computer Science I - Fall 2020
 * Instructor: Thyago Mota
 * Description: Prg04 - MadLib
 * Student Name(s): Dereck Helms
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MadLib {

    private String  story;
    private static final String LIB_FOLDER          = "libs";
    private static final String MAD_LIB_FILE_PREFIX = "madlib";
    public static final String QUESTION_PREFIX     = "Give me a(n)";
    public static final String STORY_NOT_COMPLETED_TEXT = "Sorry, but the story is not completed!";

    /*
    TODO: read the text contained in the Mad Lib file that corresponds to the given number; the contents of the file must be saved to instance variable "story".
     */
    public MadLib(int number) throws FileNotFoundException {
        String filename = MAD_LIB_FILE_PREFIX + number + ".txt";
        Scanner in = new Scanner(new FileInputStream(filename));
        StringBuilder b = new StringBuilder();
        while(in.hasNextLine())
        {
            b.append(in.nextLine());
            b.append("\n");
        }
        this.story = b.toString();
    }

    /*
    TODO: save the given story to instance variable "story"
     */
    public MadLib(String story) {
       this.story = story;
    }

    /*
    TODO: return true if there aren't any more blanks to fill in the story; false otherwise.
     */
    public boolean isCompleted() {
        return story.contains("__") == false;
        /*
        for (int i = 0; i < story.length()-1; i++) { // do I need hasNext() or hasNextLine()?
            if (story.charAt(i) != '_' && story.charAt(i+1) != '_') //is == right in this case? or .equals?
                return true;
        }

        return false; */
    }

    /*
    TODO: check if the story is completed; if NOT, return the question from the first blank
     found in the story; if the story is completed, return a blank string.
     */
    public String getQuestion() {
        /*
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        for (int i = 0; i < story.length()-1; i++) //would a while loop be better to go through the data
            if (story.charAt(i) == '_' && story.charAt(i+1) == '_') {
                return QUESTION_PREFIX + story.charAt(i);
                // do I need scanner here? I wanted to put scanner to not make it an infinite loop
                // do we use scanner in methods? I would assume not
            }
            if (input == null) {
                return STORY_NOT_COMPLETED_TEXT;
            }
        return "";

         */
        if(isCompleted()) {
            return "";
        }

        int start = story.indexOf("__");
        String sub = story.substring(start + 2);
        int end = sub.indexOf("__");

        return QUESTION_PREFIX + " " + sub.substring(0, end).replace('_', ' ') + ": ";
    }

    /*
    TODO: replace the first blank found in the story with the given answer.
     */
    public void updateStory(String answer) {
        /*
        String blank = String.valueOf(story.equals("__")); //intellij suggested this, what does it do?

        for (int i = 0; i < story.length(); i++) { // how do I make it run the entire length of the desriptor
            if (story.charAt(i) == '_' && story.charAt(i+1) == '_') // test to get first blank is wrong, would it be null?
                blank = answer;

        }*/
        int start = story.indexOf("__");
        String sub = story.substring(start + 2);
        int end = sub.indexOf("__");
        String question = story.substring(start, start + end + 4);
        story = story.replace(question, answer);
    }

    /*
    TODO: override toString by returning the story (if completed) or a message saying that the story is not completed.
     */
    @Override
    public String toString() {
        if(isCompleted()) {
            return story;
        }
        return STORY_NOT_COMPLETED_TEXT;
    }
}