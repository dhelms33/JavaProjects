/*
 * CS1050 - Computer Science I - Fall 2020
 * Instructor: Thyago Mota
 * Description: Prg04 - MadLibGame
 * Student Name(s): Dereck Helms
 */

import java.io.FileNotFoundException;
import java.util.Scanner;

public class MadLibGame {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Mad Lib #(1-3)? ");

        int number = Integer.parseInt(sc.nextLine()); // why did my professor make this a parse int? I thought that was to convert from a string to an int


        // TODO: instantiate a MadLib object based on the user selection
        MadLib madLib1 = new MadLib(number);

        // TODO: as long as the MadLib is not completed, ask the next question, record the answer, and update the storyw
        //
        while (!madLib1.isCompleted()) {
            System.out.println(madLib1.getQuestion());
            madLib1.updateStory(sc.nextLine()); //does this save and update story?
        }
        System.out.println("Story is complete!");


        // TODO: use toString to display the resulting story
        System.out.println(madLib1.toString());
    }
}