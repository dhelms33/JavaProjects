/*
 * CS1050 - Computer Science I - Fall 2020
 * Instructor: Thyago Mota
 * Description: Prg03 - SlidingPuzzle
 * Student(s) Name(s): Dereck Helms
 */

import java.awt.*;
import java.io.File;
import javax.swing.*;
import javax.swing.border.Border;
import java.io.IOException;

public class SlidingPuzzle extends JFrame {
    /**
     * All the names of the images that are supported.
     *
     * however begins with the prompt
     */
    String[] names = new String[] { "Please select an image", "monet", "flowers", "raindrops"};
    /**
     * The type of images supported
     *
     * Eg, the monet image is a png while most other images are jpgs so
     * that suffix (inclusive of the dot) gets added in here. The first
     * component is a blank because that corresponds to the prompt (Please select ....)
     */
    String[] suffix = new String[] { "", ".png", ".jpg", ".jpg"};
    static String TITLE        = "CS 1050 - Sliding Puzzle";
    static int    TITLE_HEIGHT = 20;


    SlidingPuzzle() {
        setTitle(TITLE);
        setSize((Puzzle.TILE_SIZE ) * Puzzle.GRID_SIZE,
                (Puzzle.TILE_SIZE + 10) * Puzzle.GRID_SIZE + TITLE_HEIGHT);

        JComboBox<String> combo = new JComboBox<>(names);
        combo.addActionListener(e -> {
            int idx = combo.getSelectedIndex();
            if(idx != 0) {
                try {
                    Puzzle puzzle = new Puzzle(names[idx], suffix[idx]);
                    if(getContentPane().getComponents().length == 2) {
                        getContentPane().remove(1);
                    }
                    getContentPane().add(puzzle, BorderLayout.CENTER);
                    revalidate();
                    repaint();
                    //getContentPane().repaint();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Could not load image");
                }
            }
        });
        getContentPane().setLayout(new BorderLayout());
        JPanel jpanel = new JPanel();
        jpanel.setSize(Puzzle.GRID_SIZE * Puzzle.TILE_SIZE, Puzzle.GRID_SIZE * Puzzle.TILE_SIZE);

        getContentPane().add(combo, BorderLayout.NORTH);
        getContentPane().add(jpanel, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }
    // oracle UIs that swing

    public static void main(String[] args) throws IOException {


        new SlidingPuzzle();
    }
}