import java.io.File;

public class FixNames {
    public static void main(String[] args) {
        File f = new File("res");
        /*
        for(File img : f.listFiles()) {
            if(! img.getName().startsWith("monet") &&  (! img.getName().startsWith("flowers"))) {
                img.renameTo(new File("res/coconuts-" + img.getName()));
            }
        }
*/
        File f2 = new File("res");
        for(File img : f2.listFiles()) {
            if(img.getName().startsWith("coconuts")) {
                /*
                //img.renameTo(new File("flowers-" + img.getName()));
                String[] parts = img.getAbsolutePath().split("-");
                // System.out.println(parts[2] + " " + parts[4]);
                parts[2] = Integer.toString(Integer.parseInt(parts[2]) -1);
                parts[4] = (Integer.parseInt(parts[4].substring(0,1)) -1) + parts[4].substring(1);
                System.out.println( img.getName() + " -- " +   String.join("-", parts));
                img.renameTo(new File(String.join("-", parts)));
                //  img.renameTo(new File(img.getAbsolutePath().replace("..jpg", ".jpg")));*/
                String path = img.getAbsolutePath();
                path = path.replace("coconuts","raindrops");
                path = path.replace(" (3)","");
                //System.out.println(path);
                img.renameTo(new File(path));
            }
        }
    }
}
